

#' Dispaly a list of colors using pie chart
#'
#' @param colors mutliple colors
#'
#' @return
#' @export
#'
#'
show_colors_as_pie <- function(colors) {
  # show the color palettes like the function like display.brewer.pal
  pie(x = rep(1, length(colors)),
      label = colors,
      col = colors)
}



#' Make a list of color for an annotation
#'
#' @param x is a numeric or character vector for an annotation
#' @param color_name character, one of brewer.pal.info
#'
#' @return a list of  HEX code colors
#' @export
#'

make_color_list <- function(x, color_name) {

  x = x[!is.na(x)]
  unique_val = unique(x)
  count_unique_val = length(unique_val)


  if (is.character(x)) {
    lst_name = unique_val
  } else if (is.numeric(x)) {
    lst_name = seq_along(unique_val)
  } else {
    stop("The data must be numeric or character!")
  }

  pick.col = brewer.pal(9, color_name)
  col_hex = colorRampPalette(pick.col)(count_unique_val)

  names(col_hex) = lst_name
  return(col_hex)
}


#' Make a legend param for one HeatmapAnnotation object
#'
#' @param x a list or a column of a dataframe
#'
#' @return
#' @export
#'
#'
make_legend_param <- function(x) {

  x_flat = x[[1]]
  x_flat = x_flat[!is.na(x_flat)]
  unique_val = unique(x_flat)

  param_lst = list(
    nrow = length(unique_val),
    title = names(x),
    title_position = 'topcenter',
    legend_direction = 'vertical',
    title_gp = gpar(fontsize = 12, fontface = 'bold'),
    labels_gp = gpar(fontsize = 12, fontface = 'bold')
  )
  result = list(param_lst)
  names(result) = names(x)

  return(result)
}

#' Make a list of legend param based on meta_df
#'
#' @param meta_df dataframe each column for one annotation
#'
#' @return
#' @export
#'
#'
make_legend_param_list <- function(meta_df) {

  result = list()
  data = as.list(meta_df)
  for (i in seq_along(data)) {
    item = data[i]
    legend_param = make_legend_param(item)
    result = append(result, legend_param)
  }
  return(result)
}
