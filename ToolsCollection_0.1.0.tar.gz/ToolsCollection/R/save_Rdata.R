#' Save dataframes, ggplots and functions
#'
#' @param obj_pattern a pattern for filtering the objects to be saved
#' @param save_func logic, if you want to save customized function
#' @param file_name the file name of the Rdata file
#' @param preview logic, preview the objects to be saved
#'
#'
#'
#' @export
#'
#'
#'
#'
#'
save_Rdata <- function(obj_pattern="^p_|_data$" ,
                       save_func=TRUE,
                       preview = TRUE,
                       file_name) {
  env_name = sys.frame(-1)
  obj = ls(name=env_name)
  obj_save = grep(pattern = obj_pattern, obj,value = TRUE)
  func_save = obj[sapply(obj, function(x) is.function(get(x)))]

  if (save_func){
    save_lst = c(obj_save, func_save)

  } else{
    save_lst = obj_save
  }

  if (preview) {

    cat("Preview...===========================\n")
    cat("\nDataframes and ggplots------\n\n")
    cat_or_print(obj_save)

    cat("\nCustomized functions------\n\n")
    cat_or_print(func_save)

    cat(func_save)

  }

  cat("\n\n===============================\n")
  cat("Do you want to continue to save or change pattern")
  cat("\n1 - Continue...\n2 - Exit... \n")
  resp <- readline(prompt ="Input: ")
  continue_run = (resp == 1)
  stopifnot(continue_run)

  cat("Saving...===========================\n")
  save(list = save_lst, file = file_name)
  cat("\nDone!===============================\n")

}




#' A wrapper function to chaose cat or print command for showing obj information
#'
#' @param obj the vector containing the names of objects that be printed
#'
#'
#'
#'
#'
#'


cat_or_print <- function(obj) {
  if (length(obj)== 0) cat(obj) else print(obj)

}

