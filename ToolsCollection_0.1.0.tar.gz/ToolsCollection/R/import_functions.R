
# Some useful keyboard shortcuts for package authoring:
#
#   Install Package:           'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'


#' Reading data from  worksheets of excel spreadsheet
#'
#'
#' @param path    the full path of the excel file
#' @param sheet_name   the pattern for matching worksheets
#' @param ...   run ?read_excel for more parameters
#'
#' @importFrom  readxl read_excel excel_sheets
#'
#' @return a dataframe
#' @export
#'
#'
#'
#'
read_worksheet <- function(path, sheet_name, ...) {
  #
  # sheet_name: the partial string  of the sheet_name
  # ... parameter if we need to assign the range and col_type
  # return


  sheet = grep(sheet_name, excel_sheets(path), value = TRUE)
  data <- read_excel(path = path,
                     sheet = sheet,
                     ...
  )
  return(data)
}
#
#' A wrapper function for getting all the worksheet names
#'
#' @param query_string  a string representing a pattern
#' @param path  the full path of the excel file
#'
#' @return a list of sheet name
#'
#'
#'
#'


get_sheet_list <- function(query_string, path) {
  sheet = grep(query_string, excel_sheets(path), value = TRUE)
  names(sheet) = sheet
  return(sheet)

}



#' Calculate cell doubling time
#'
#' @param start_density cell density when seeding cells
#' @param end_density   cell density when harvesting cells
#' @param days days for culture
#'
#' @return doubling time in hours
#' @export
#'
#'
#'
cal_doubling_time <- function(start_density, end_density, days = 7) {
  # return hours
  doubling_time = 24*days*log(2)/(log(end_density)- log(start_density))
  return (doubling_time)
}

