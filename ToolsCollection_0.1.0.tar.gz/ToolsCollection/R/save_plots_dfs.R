#' Save dataframes as an excel file
#'
#' @param ... multiple dataframe objects that separated by ","
#' @param df_list a list with dataframe objects or names of dataframe objects
#' @param file_xlsx  file path of the excel file
#'
#'
#' @return
#' @export
#'
#'
#'
dfs_to_xlsx <- function(..., df_list = NULL, file_xlsx) {


  if(missing(file_xlsx)) {
    stop("`file_xlsx` must be specified")
  }


  names_dot_list = as.character(substitute(list(...)))[-1L]
  if(missing(df_list) && !length(names_dot_list)) {
    warning("nothing specified to be save!")
  }


  df_list_is_char =  all(sapply(df_list, is.character))

  if (df_list_is_char) {

    obj_list = lapply(df_list, function(item) eval(parse(text=item)))
    names_obj_list = as.vector(df_list)

  } else {

    obj_list = df_list
    names_obj_list = names(df_list)

  }

  objects_list <- c(list(...), obj_list)
  names_list <- c(names_dot_list, names_obj_list)


  file = rename_if_exist(file_xlsx)
  walk2(objects_list, names_list,
        ~write.xlsx2(
          x = .x,
          file = file,
          sheetName = .y,
          col.names = TRUE,
          row.names = TRUE,
          append = TRUE)
  )
}


#' Rename the file_name if the file exits in the hard drive
#'
#' @param file_name
#'
#' @return
#'
#'
#'
rename_if_exist <- function(file_name) {

  if (file.exists(file_name)) {
    file_no_ext = file_path_sans_ext(file_name)
    file_extension = file_ext(file_name)
    current_date = format(Sys.Date(), "%Y%m%d")
    random_num = round(runif(1, 1, 2), 2)*100
    file_name = paste0(file_no_ext, "_",
                       current_date, "_",
                       random_num, ".", file_extension)
  }
  return(file_name)
}



#' Save multiple plots as a pptx file
#'
#' @param ... multiple ggplots separated by ","
#' @param plots_list a list of names of plots
#' @param file_name the file name for file_name
#'
#' @return NULL
#' @export
#'
#'
plots_to_pptx <- function(..., plots_list=NULL, file_name) {

  if (missing(file_name)) {
    stop("The file_name must be specified!")
  }

  if (!length(plots_list)) {
    stop("The plots list is empty!")
  }


  names_dot_list = as.character(substitute(list(...)))[-1L]
  if (missing(plots_list) && !length(names_dot_list)) {
    warning("Nothing specified to be saved!")
  }

  # Get the list of objects(here is ggplot objects)
  plots_list_is_char = all(sapply(plots_list, is.character))
  if (plots_list_is_char) {

    obj_list = lapply(plots_list, function(item) eval(parse(text=item)))
    names_obj_list = as.vector(plots_list)

  } else {

    obj_list = plots_list
    names_obj_list = names(plots_list)

  }



  objects_list <- c(list(...), obj_list)
  names_list <- c(names_dot_list, names_obj_list)



  if (file.exists(file_name)) {
    file_name = rename_if_exist(file_name)
  }

  lapply(obj_list, function(x){
    graph2ppt(x = x,
              file = file_name,
              aspect = 1.33,
              width = 12,
              append = TRUE)
  })
}
