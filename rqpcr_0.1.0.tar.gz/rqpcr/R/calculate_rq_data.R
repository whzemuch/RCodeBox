#' Title
#'
#' @param data_wide data frame, from the result of process_data function
#' @param data_sample_info data frame,  sample information
#' @param internal_ctrl string, house keep gene name
#'
#' @importFrom dplyr select left_join
#' @importFrom tidyr pivot_longer
#'
#'
#' @return data frame
#' @export
#'
#' @examples
#'
calculat_rq_data <- function(data_wide,
                             data_sample_info,
                             internal_ctrl = "GAPDH") {

  has_sample_name = "sample_name" %in% colnames(data_wide) &
                     "sample_name" %in% colnames(data_sample_info)
  stopifnot(has_sample_name)

  if (missing(internal_ctrl)) {
    internal_ctrl = "GAPDH"
  }


  data_rq = data_wide %>%
    Calculate_relative_exp(internal_ctrl = internal_ctrl,
                           format = "wide") %>%
    select(-!!interal_ctrl) %>%
    pivot_longer(cols = -sample_name,
                 names_to = "Gene",
                 values_to = "RelativeExp") %>%
    left_join(data_sample_info, by = "sample_name")
  return(data_rq)
}
