#' Save multiple dataframes to a excel spreadsheet
#'
#' @param df_list dataframes for saving, named list
#' @param file_xlsx  excel spreadsheet, string
#' @importFrom xlsx write.xlsx2
#' @importFrom purrr walk2
#'
#' @return None
#' @export
#'
#' @examples
save_dfs_as_xlsx <- function(df_list, file_xlsx) {

  file = rename_if_exist(file_xlsx)

  walk2(df_list, names(df_list),
        ~xlsx::write.xlsx2(
          x = .x,
          file = file,
          sheetName = .y,
          col.names = TRUE,
          row.names = TRUE,
          append = TRUE)
  )
}


#' Save plots to a pptx file
#'
#'
#' @param plots_list ggplot objects in a charactor vector
#' @param file_name the name for the pptx file
#' @param ...
#'
#' @importFrom export graph2ppt
#'
#' @return
#' @export
#'
#' @examples
save_plots_pptx <- function(plots_list, file_name, ...) {


  if (file.exists(file_name)) {
    file_name = rename_if_exist(file_name)
  }

  for( p in plots_list) {
    print(p)
    graph2ppt(x = eval(parse(text = p)),
              file = file_name,
              aspect = 1.33,
              width = 12,
              append = TRUE)
  }

}
