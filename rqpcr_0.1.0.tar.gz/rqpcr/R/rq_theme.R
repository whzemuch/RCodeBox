#' A theme for RQ-PCR
#'
#' @param base_size  integer
#' @param base_family string
#' @param base_line_size interger
#' @param base_rect_size integer
#'

#'
#' @return A theme for ggplot
#' @export
#'
#' @examples
#'
rq_theme <- function(base_size = 11,
                     base_family = "",
                     base_line_size = base_size/22,
                     base_rect_size = base_size/22) {

    ggplot2::theme_grey(base_size = base_size,
               base_family = base_family,
               base_line_size = base_line_size,
               base_rect_size = base_rect_size

               ) %+replace%
      ggplot2::theme(panel.background = element_rect(fill = "white", colour = NA),
            panel.border = element_rect(fill = NA,  colour = "grey20"),
            panel.grid = element_line(colour = "grey92"),
            #panel.grid.minor = element_line(size = rel(0.5)),
            #strip.background = element_rect(fill = "grey85", colour = "grey20"),
            strip.background = element_blank(),
            strip.text = element_text(face = "bold", size = 10),
            panel.grid.minor = element_blank(),
            panel.grid.major.x = element_blank(),
            axis.title = element_text(face = "bold"),
            plot.title = element_text(hjust = 0.5, face = "bold"),
            axis.text.x = element_text(angle = 90,
                                       hjust = 0.5, vjust = 0.5),
            #legend.key = element_rect(fill = "white", colour = NA),
            complete = TRUE)
  }
