#' Preprocess data: clean target gene name and calculate the average of the replicates
#'
#' @param data_wide data frame, a wide form data frame,
#' @param remove_prefix logic, remove prefix of target gene name
#' @param prefix  string, the pattern parameter of grep
#' @importFrom dplyr rename_with group_by summarise
#'
#' @return data frame, a wide form data frame
#' @export
#'
#' @examples
preprocess_data <- function(data_wide,
                            remove_prefix = TRUE,
                            prefix = "0h_") {
  #data_wide: sample_name, plus target gene names as colnames
  has_sample_name = "sample_name" %in% colnames(data_wide)
  stopifnot(has_sample_name)

  if (remove_prefix) {
    data_wide = data_wide %>%
      rename_with(~(gsub(prefix, "", .x))) %>%
      group_by(sample_name) %>%
      summarise(across(where(is.numeric), mean))
  } else{
    data_wide = data_wide %>%
      group_by(sample_name) %>%
      summarise(across(where(is.numeric), mean))
  }
  return(data_wide)

}
