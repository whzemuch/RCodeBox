#' Rename the file name (add dateand random number)if the file exists
#'
#' @param file_name file path, string
#' @importFrom tools file_path_sans_ext file_ext
#' @importFrom stats runif
#' @improtFrom utils data read.csv
#'
#' @return a new string with current date and random number if the file_name exist
#'
#'
#'
rename_if_exist <- function(file_name) {



  if (file.exists(file_name)) {
    file_no_ext = file_path_sans_ext(file_name)
    file_extension = file_ext(file_name)
    current_date = format(Sys.Date(), "%Y%m%d")
    random_num = round(runif(1, 1, 2), 2)*100
    file_name = paste0(file_no_ext, "_",
                       current_date, "_",
                       random_num, ".", file_extension)
  }
  return(file_name)
}


#' Extract sample names from a dataframe
#'
#'
#' @param data_wide  a dataframe with "sample_name" column
#'
#' @return sample names, a character vector
#' @export
#'
#'
extract_sample_name <- function(data_wide) {


  # Check if the dataframe has "sample_name" column
  col_names = colnames(data_wide)
  sample_name_exist = "sample_name" %in% col_names
  stopifnot(sample_name_exist)

  data$wide %>%
    dplyr::select(sample_name) %>%
    dplyr::distinct() %>%
    dplyr::arrange(sample_name) %>%
    dplyr::pull()
}

