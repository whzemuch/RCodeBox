#' Plotting for RQ_PCR
#'
#'
#' @param data data frame
#' @param x_aes variable for x
#' @param y_aes variable for y
#' @param row_facet  variable for the row of a facet
#' @param col_facet variable for the column of a facet
#' @param fill  variable for filling
#'
#' @importFrom ggplot2 ggplot vars aes_string theme_bw theme geom_col facet_grid stat_summary element_blank element_text
#'
#' @return a ggplot object
#' @export
#'
#' @examples
plot_rq <- function(data,
                    x_aes = "passage",
                    y_aes = "RelativeExp",
                    row_facet = "Gene",
                    col_facet = "surface",
                    fill = "cells") {
  ggplot(data, aes_string(x_aes, y_aes, fill = fill)) +
    geom_col() +
    facet_grid(row = vars(.data[[row_facet]]),
               col = vars(.data[[col_facet]]),
               scales = "free_y") +
    ggplot2::theme_bw() +
    ggplot::theme(
      strip.background = element_blank(),
      strip.text = element_text(face = "bold", size = 10),
      panel.grid.minor = element_blank(),
      panel.grid.major.x = element_blank(),

      axis.title = element_text(face = "bold"),
      plot.title = element_text(hjust = 0.5, face = "bold"),
      plot.subtitle = element_text(hjust = 0.5),
      axis.text.x = element_text(angle = 90,
                                 hjust = 0.5, vjust = 0.5),
      legend.position = "bottom"
    )
}


#'  a custormided geom function
#'
#' @return a geom
#' @export
#'
#'
geom_mean <- function() {
  list(
    stat_summary(fun = "mean", geom = "bar", fill = "grey70"),
    stat_summary(fun.data = "mean_cl_normal", geom = "errorbar", width = 0.4)
  )
}
